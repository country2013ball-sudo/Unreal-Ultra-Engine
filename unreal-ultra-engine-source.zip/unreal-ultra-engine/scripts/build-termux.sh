#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
printf '%s\n' 'UNREAL ULTRA: checking build tools'
command -v java >/dev/null || { echo 'Install a JDK first: pkg install openjdk-17'; exit 1; }
command -v gradle >/dev/null || { echo 'Gradle is not installed. On Termux: pkg install gradle (if available for your repo).'; exit 1; }
command -v sdkmanager >/dev/null || { echo 'Android SDK command-line tools/sdkmanager not found. For a reliable Android build, use the included GitHub Actions workflow or Codespaces with Android SDK installed.'; exit 1; }
gradle testDebugUnitTest assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
