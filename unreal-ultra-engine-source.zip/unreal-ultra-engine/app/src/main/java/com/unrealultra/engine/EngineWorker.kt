package com.unrealultra.engine

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Deferrable maintenance only. WorkManager is not a real-time or always-running service. */
class EngineWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val diagnostics = DiagnosticsReader(applicationContext).read()
        // Keep this worker deliberately lightweight: no cache clearing, app killing, or privileged writes.
        applicationContext.getSharedPreferences("engine_state", Context.MODE_PRIVATE).edit()
            .putLong("last_maintenance_epoch_ms", System.currentTimeMillis())
            .putBoolean("last_low_memory", diagnostics.lowMemory)
            .apply()
        Result.success()
    } catch (_: SecurityException) {
        Result.failure()
    } catch (_: RuntimeException) {
        if (runAttemptCount < 2) Result.retry() else Result.failure()
    }
}
