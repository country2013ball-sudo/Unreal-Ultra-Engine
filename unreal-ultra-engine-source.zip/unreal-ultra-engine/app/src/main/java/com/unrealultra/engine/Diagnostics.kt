package com.unrealultra.engine

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import java.util.Locale

data class DeviceDiagnostics(
    val model: String,
    val androidVersion: String,
    val sdk: Int,
    val totalRamBytes: Long,
    val availableRamBytes: Long,
    val lowMemory: Boolean,
    val thermalStatus: Int?,
    val thermalLabel: String,
    val appHeapUsedBytes: Long
) {
    val ramUsedPercent: Int get() = if (totalRamBytes <= 0) 0 else (((totalRamBytes - availableRamBytes).coerceAtLeast(0) * 100) / totalRamBytes).toInt().coerceIn(0, 100)
    val totalRamLabel: String get() = formatBytes(totalRamBytes)
    val availableRamLabel: String get() = formatBytes(availableRamBytes)
    val appHeapLabel: String get() = formatBytes(appHeapUsedBytes)
}

fun formatBytes(bytes: Long): String {
    if (bytes < 0) return "Unavailable"
    val units = listOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = 0
    while (value >= 1024 && unit < units.lastIndex) { value /= 1024; unit++ }
    return String.format(Locale.US, "%.1f %s", value, units[unit])
}

class DiagnosticsReader(private val context: Context) {
    fun read(): DeviceDiagnostics {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo().also(manager::getMemoryInfo)
        val thermal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching { (context.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus }.getOrNull()
        } else null
        return DeviceDiagnostics(
            model = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidVersion = Build.VERSION.RELEASE ?: "Unknown",
            sdk = Build.VERSION.SDK_INT,
            totalRamBytes = info.totalMem,
            availableRamBytes = info.availMem,
            lowMemory = info.lowMemory,
            thermalStatus = thermal,
            thermalLabel = thermalLabel(thermal),
            appHeapUsedBytes = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()
        )
    }
}

fun thermalLabel(status: Int?): String = when (status) {
    null -> "Unavailable on this device"
    PowerManager.THERMAL_STATUS_NONE -> "Normal"
    PowerManager.THERMAL_STATUS_LIGHT -> "Light"
    PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
    PowerManager.THERMAL_STATUS_SEVERE -> "Severe — reduce workload"
    PowerManager.THERMAL_STATUS_CRITICAL -> "Critical — stop heavy workload"
    PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
    PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown threshold"
    else -> "Unknown status ($status)"
}
