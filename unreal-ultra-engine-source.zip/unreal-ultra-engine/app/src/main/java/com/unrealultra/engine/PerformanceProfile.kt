package com.unrealultra.engine

/** Controls this app's own diagnostic cadence and maintenance behavior, not system CPU clocks. */
enum class PerformanceProfile(val title: String, val description: String, val refreshSeconds: Long, val maintenanceEnabled: Boolean) {
    BALANCED("UNREAL BALANCED", "Balanced diagnostics with low background overhead.", 60, true),
    FLUID("UNREAL FLUID", "Faster in-app refresh while the dashboard is open.", 15, true),
    GAMING("UNREAL GAMING", "Minimal background work; observe thermal state before long sessions.", 120, false),
    BATTERY("UNREAL BATTERY", "Slow diagnostics and fewer maintenance jobs.", 300, false);

    companion object {
        fun fromStored(value: String?): PerformanceProfile = entries.firstOrNull { it.name == value } ?: BALANCED
    }
}

data class ProfilePolicy(val refreshSeconds: Long, val maintenanceEnabled: Boolean, val thermalCaution: Boolean)

fun policyFor(profile: PerformanceProfile, thermalStatus: Int?): ProfilePolicy = ProfilePolicy(
    refreshSeconds = if (thermalStatus != null && thermalStatus >= 3) maxOf(profile.refreshSeconds, 120L) else profile.refreshSeconds,
    maintenanceEnabled = profile.maintenanceEnabled && (thermalStatus == null || thermalStatus < 3),
    thermalCaution = thermalStatus != null && thermalStatus >= 2
)
