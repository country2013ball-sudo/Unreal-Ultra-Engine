package com.unrealultra.engine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.OfflineBolt
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scheduleMaintenance(this, PerformanceProfile.fromStored(getSharedPreferences("engine_state", 0).getString("profile", null)))
        setContent { UnrealApp() }
    }
}

private fun scheduleMaintenance(context: android.content.Context, profile: PerformanceProfile) {
    val manager = WorkManager.getInstance(context)
    if (!profile.maintenanceEnabled) {
        manager.cancelUniqueWork("unreal-ultra-maintenance")
        return
    }
    // WorkManager's minimum periodic interval is 15 minutes; this is intentionally inexact.
    val intervalMinutes = if (profile == PerformanceProfile.BATTERY) 60L else 15L
    val request = PeriodicWorkRequestBuilder<EngineWorker>(intervalMinutes, TimeUnit.MINUTES).build()
    manager.enqueueUniquePeriodicWork("unreal-ultra-maintenance", ExistingPeriodicWorkPolicy.UPDATE, request)
}

@Composable
private fun UnrealApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("engine_state", 0) }
    var profile by remember { mutableStateOf(PerformanceProfile.fromStored(prefs.getString("profile", null))) }
    var diagnostics by remember { mutableStateOf(DiagnosticsReader(context).read()) }
    var dark by remember { mutableStateOf(true) }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("UNREAL ULTRA", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                            Text("SAMSUNG PERFORMANCE ENGINE", style = MaterialTheme.typography.labelMedium)
                        }
                        TextButton(onClick = { dark = !dark }) { Text(if (dark) "Light" else "Dark") }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${profile.title}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(profile.description)
                            Text("Adaptive policy: ${policyFor(profile, diagnostics.thermalStatus).refreshSeconds}s dashboard refresh target", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item { Text("PERFORMANCE PROFILES", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                items(PerformanceProfile.entries) { option ->
                    Card(onClick = {
                        profile = option
                        prefs.edit().putString("profile", option.name).apply()
                        scheduleMaintenance(context, option)
                    }, shape = RoundedCornerShape(18.dp), border = if (profile == option) CardDefaults.outlinedCardBorder() else null) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(option.title, fontWeight = FontWeight.Bold)
                                Text(option.description, style = MaterialTheme.typography.bodySmall)
                                Text("Refresh target ${option.refreshSeconds}s · maintenance ${if (option.maintenanceEnabled) "enabled" else "reduced"}", style = MaterialTheme.typography.labelSmall)
                            }
                            RadioButton(selected = profile == option, onClick = {
                                profile = option
                                prefs.edit().putString("profile", option.name).apply()
                                scheduleMaintenance(context, option)
                            })
                        }
                    }
                }
                item { Text("LIVE DEVICE DIAGNOSTICS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                item { MetricCard("Device", diagnostics.model, "Android ${diagnostics.androidVersion} (API ${diagnostics.sdk})", Icons.Default.OfflineBolt) }
                item { MetricCard("Available memory", diagnostics.availableRamLabel, "${diagnostics.ramUsedPercent}% estimated system RAM in use · total ${diagnostics.totalRamLabel}", Icons.Default.Memory) }
                item { MetricCard("Thermal status", diagnostics.thermalLabel, if (policyFor(profile, diagnostics.thermalStatus).thermalCaution) "Caution: profile activity is reduced where possible" else "Android thermal safeguards remain enabled", Icons.Default.Thermostat) }
                item { MetricCard("Engine process heap", diagnostics.appHeapLabel, "This app's managed heap estimate; not total app PSS", Icons.Default.BatteryChargingFull) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { diagnostics = DiagnosticsReader(context).read() }, modifier = Modifier.weight(1f)) { Text("Refresh diagnostics") }
                        OutlinedButton(onClick = {
                            scheduleMaintenance(context, profile)
                        }, modifier = Modifier.weight(1f)) { Text("Queue maintenance") }
                    }
                }
                item { Text("HONEST LIMITS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                item { Text("Non-root mode cannot set CPU/GPU clocks, change Samsung's global animation scales, kill other apps safely, or replace the system Control Centre. WorkManager is deferred and may run later than requested. Profiles control this app's own policies only.", style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.labelLarge)
                Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(detail, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
