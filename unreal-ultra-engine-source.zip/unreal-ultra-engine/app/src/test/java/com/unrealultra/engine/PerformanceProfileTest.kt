package com.unrealultra.engine

import org.junit.Assert.*
import org.junit.Test

class PerformanceProfileTest {
    @Test fun unknownStoredProfileFallsBackToBalanced() {
        assertEquals(PerformanceProfile.BALANCED, PerformanceProfile.fromStored("future-profile"))
        assertEquals(PerformanceProfile.BALANCED, PerformanceProfile.fromStored(null))
    }

    @Test fun profilesHaveDistinctPolicies() {
        assertEquals(15L, policyFor(PerformanceProfile.FLUID, 0).refreshSeconds)
        assertEquals(300L, policyFor(PerformanceProfile.BATTERY, 0).refreshSeconds)
        assertTrue(policyFor(PerformanceProfile.BALANCED, 0).maintenanceEnabled)
        assertFalse(policyFor(PerformanceProfile.GAMING, 0).maintenanceEnabled)
    }

    @Test fun severeThermalStateReducesActivityAndFlagsCaution() {
        val policy = policyFor(PerformanceProfile.FLUID, 3)
        assertEquals(120L, policy.refreshSeconds)
        assertFalse(policy.maintenanceEnabled)
        assertTrue(policy.thermalCaution)
    }

    @Test fun moderateThermalStateFlagsCautionWithoutSevereThrottlePolicy() {
        val policy = policyFor(PerformanceProfile.BALANCED, 2)
        assertEquals(60L, policy.refreshSeconds)
        assertTrue(policy.maintenanceEnabled)
        assertTrue(policy.thermalCaution)
    }

    @Test fun unavailableThermalTelemetryDoesNotInventCaution() {
        val policy = policyFor(PerformanceProfile.BALANCED, null)
        assertFalse(policy.thermalCaution)
        assertTrue(policy.maintenanceEnabled)
    }
}
