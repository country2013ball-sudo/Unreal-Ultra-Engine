# UNREAL ULTRA ENGINE FOR SAMSUNG

A non-root Android diagnostics and adaptive-app-policy starter for Samsung Galaxy devices, including One UI Core and flagship S-series devices. The same APK targets Android API 29+; hardware/API capabilities are detected at runtime.

## Honest implementation status (0.1.0)

Implemented in source:
- Native Jetpack Compose dashboard and four persisted profile selections.
- Device/model/Android SDK, system available/total RAM, app managed-heap estimate, and Android thermal status diagnostics.
- A pure Kotlin adaptive policy that reduces this app's own activity under severe thermal status.
- Lightweight WorkManager maintenance worker and unique periodic scheduling (15-minute minimum interval).
- Unit tests for profile fallback, profile policy differences, and thermal adaptation.
- GitHub Actions workflow that runs unit tests, assembles a debug APK, and uploads it as an artifact.

Not implemented / not claimed:
- No verified build or test result has been produced in this environment yet.
- No real-device measurements yet; no performance gains are claimed.
- Profiles do not control system CPU/GPU clocks, governor, scheduler, global animation scales, other apps, or Samsung's protected Control Centre.
- The dashboard refreshes only when the user taps Refresh; profile refresh values currently describe intended policy targets and thermal policy. Automatic live UI polling is not implemented in this first source drop.
- No boot receiver, foreground service, root module, ADB module, frame-timing capture, launch-time benchmark, or battery benchmark yet.

## Build in GitHub Codespaces / GitHub Actions

Requirements: JDK 17, Android SDK platform 36 and build tools 36.0.0, Gradle 8.11.1.

```bash
gradle testDebugUnitTest
gradle assembleDebug
```

The APK output is `app/build/outputs/apk/debug/app-debug.apk`. The included GitHub Actions workflow builds it and uploads it as an artifact on pushes, pull requests, or manual dispatch. Download the artifact from the Actions run; an APK is not checked into the source tree.

## Termux notes

Android builds in Termux can be fragile because SDK command-line tools and Gradle/Java compatibility vary. Install a compatible JDK, Gradle and Android SDK tools, then run `./scripts/build-termux.sh`. If `sdkmanager` or the Android platform packages are unavailable, use GitHub Actions/Codespaces instead; do not treat a failed local setup as an app-code test result.

## Install / uninstall

After building, install the debug APK with `adb install -r app/build/outputs/apk/debug/app-debug.apk` from an authorized ADB host. On a phone-only workflow, download the Actions artifact, extract the APK and open it with the Android package installer. Uninstall via Android Settings → Apps → UNREAL ULTRA ENGINE → Uninstall.

## Safety

No root required. No app killing, cache clearing, hidden APIs, SELinux changes, thermal bypasses, or wake locks. Android may defer or stop background work; WorkManager periodic work has a minimum 15-minute interval and is inexact. This app cannot guarantee permanent execution.

## Verified platform API references

- `ActivityManager.MemoryInfo`: https://developer.android.com/reference/android/app/ActivityManager.MemoryInfo
- `PowerManager` thermal status APIs: https://developer.android.com/reference/android/os/PowerManager
- `PeriodicWorkRequest`: https://developer.android.com/reference/androidx/work/PeriodicWorkRequest

## License

Apache-2.0. See `LICENSE`.
